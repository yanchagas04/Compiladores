1. Instalação:
    Para instalar, dê duplo clique em install.bat
2. Como usar:
    Para iniciar o Static Checker, dê duplo clique em run.bat