package source;


public enum Escopo {
    variavel,
    nomPrograma,
    nomFuncao,
    antesNomeFunc;
}
